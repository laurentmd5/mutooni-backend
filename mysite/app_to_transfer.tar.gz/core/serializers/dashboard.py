# core/serializers/dashboard.py
from rest_framework import serializers

class DashboardStatsSerializer(serializers.Serializer):
    """
    Sérialiseur pour les statistiques du tableau de bord.
    """
    total_vente = serializers.DecimalField(
        max_digits=12, 
        decimal_places=2,
        help_text="Total des ventes pour le mois en cours"
    )
    total_achat = serializers.DecimalField(
        max_digits=12, 
        decimal_places=2,
        help_text="Total des achats pour le mois en cours"
    )
    total_stock = serializers.IntegerField(
        help_text="Nombre total d'articles en stock"
    )