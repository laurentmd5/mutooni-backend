# core/views/dashboard.py
from rest_framework.views import APIView
from rest_framework.response import Response
from core.models import Vente, Achat, Produit
from django.db.models import Sum
from django.utils import timezone
from datetime import timedelta
from core.serializers.dashboard import DashboardStatsSerializer
from drf_spectacular.utils import extend_schema  # ✅

class DashboardStatsView(APIView):
    """Calcule et sérialise les statistiques pour le tableau de bord"""

    @extend_schema(
        responses=DashboardStatsSerializer  # ✅ pour que Spectacular détecte le schéma
    )
    def get(self, request):
        today = timezone.now().date()
        first_day_of_month = today.replace(day=1)
        last_day_of_month = (first_day_of_month + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        ventes_mois = Vente.objects.filter(
            date__date__range=[first_day_of_month, last_day_of_month],
            statut='PAYEE'
        ).aggregate(total_vente=Sum('total'))['total_vente'] or 0

        achats_mois = Achat.objects.filter(
            date__date__range=[first_day_of_month, last_day_of_month],
            statut__in=['PAYE', 'PARTIEL']
        ).aggregate(total_achat=Sum('total'))['total_achat'] or 0

        stock_total = Produit.objects.aggregate(
            total_stock=Sum('stock_actuel')
        )['total_stock'] or 0

        data = {
            'total_vente': float(ventes_mois),
            'total_achat': float(achats_mois),
            'total_stock': int(stock_total)
        }

        serializer = DashboardStatsSerializer(data=data)
        serializer.is_valid(raise_exception=True)

        return Response(serializer.data)
